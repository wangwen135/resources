# WHWTools

## 我的小工具  

开发中...没进行整理的  
淡定...  
坚持...  



[下载 whw-tools-0.0.2-SNAPSHOT-bin.tar.gz](https://github.com/wangwen135/resources/raw/master/WHWTools/release/whw-tools-0.0.2-SNAPSHOT-bin.tar.gz)
---

### 软件截图  
![image](https://github.com/wangwen135/resources/blob/master/WHWTools/image/all.jpg)

#### Base64  
![image](https://github.com/wangwen135/resources/blob/master/WHWTools/image/Base64.jpg)

#### FileToBase64  
![image](https://github.com/wangwen135/resources/blob/master/WHWTools/image/fileToBase64.jpg)

#### Hex  
![image](https://github.com/wangwen135/resources/blob/master/WHWTools/image/Hex.jpg)

#### URLEncode  
![image](https://github.com/wangwen135/resources/blob/master/WHWTools/image/URLEncode.jpg)

#### Native2Ascii  
![image](https://github.com/wangwen135/resources/blob/master/WHWTools/image/Native2Ascii.jpg)

#### MD5  
![image](https://github.com/wangwen135/resources/blob/master/WHWTools/image/MD5.jpg)

#### SHA1  
![image](https://github.com/wangwen135/resources/blob/master/WHWTools/image/SHA1.jpg)

#### SHA1  
![image](https://github.com/wangwen135/resources/blob/master/WHWTools/image/SHA1.jpg)

#### AES128Encrypt  
AES加密解密  
![image](https://github.com/wangwen135/resources/blob/master/WHWTools/image/AES128Encrypt.jpg)

#### DBView
查看数据库用的  
![image](https://github.com/wangwen135/resources/blob/master/WHWTools/image/DBView.jpg)

#### DBGenerate  
主要用于根据数据库生成代码，使用velocity模板
![image](https://github.com/wangwen135/resources/blob/master/WHWTools/image/DBGenerate.jpg)

[代码生成模板文件例子](https://github.com/wangwen135/resources/tree/master/WHWTools/velocityTemplate)



